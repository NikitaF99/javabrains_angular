export class BlogPost {
    // adding variables
    // title:string | undefined;
    // summary: string | undefined;

    constructor(public title:string , public summary:string){

    }
 
}
